import time
## dd/mm/yyyy format
print (time.strftime("%d/%m/%Y"))

# mm/dd/yy format
print ("Date:",time.strftime("%x"))

#military time
print ("Current time:",time.strftime("%X"))
