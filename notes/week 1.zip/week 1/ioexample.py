# ioexample.py
# Written by <your name here>
# Date: <today's date>
# Lab: <lab number here>
# Course Number: <your course number here>

############ Define Variables ###########
#
containers = 'glasses'    #Type of containers used.
liquid = 'water'          #What is contained in the containers.
location = 'on the table' #Location of containers.
############ Output Variable Description #################
#
#ask for the amount of needed containers
#
amount=int(input("Enter desired amount of containers needed "));
           
print ("This script has four variables pre-defined in it.")
print 

print ("The variables are as follows:")

print ("name: amount", "data type:", type (amount), "value:", amount)

print ("name: containers", "data type:", type (containers), "value:", containers)

print ("name: liquid", "data type:", type (liquid), "value:", liquid)

print ("name: location", "data type:", type (location), "value:", location)
print 

############ Output Sentence Using Variables #############
#
print ("There are", amount, containers, "full of", liquid, location)
print 
