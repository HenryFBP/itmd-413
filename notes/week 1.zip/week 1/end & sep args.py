'''prog 1
'''
import time, keyword
print("hello\n",end =' b ') #end arg
print("hey"," man", "cow", sep="       ") #sep a
print (keyword.kwlist)
value1=2.0
value2=12
print(value1 * value2)
value = 3.3356
print ("hi")
print ("%06.2f" % value)


 
