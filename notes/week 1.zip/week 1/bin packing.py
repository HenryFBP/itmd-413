'''
Program: Bin packing
Best fit algorithm deployed
optimize container spacing for shipment
'''
import keyword
#set vars to include available boxes to ship

g = l = m = s = 0

#get user input
snum = int(input("enter cells to box "))

#perform calculations for best fit
g = num // 50    
l = (num % 50) // 25
m = (num % 25) // 10
s = (num % 50) % 25 % 10 

#display container amounts to ship
print() #blank line
print("Shipment container totals:")
print("giants  = ",g)
print("large   = ",l)
print("mediums = ", m)
print("small   = ", s)

'''alternative'''
print() #blank line
print("Shipment container totals:")
print("giants = ",g,end="")
print(", large = ",l,end="")
print(", mediums = ", m,end="")
print(", small = ", s)
